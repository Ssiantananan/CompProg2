/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package MotorPHPayrollApp_CompProg2;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.Timer;


/**
 *
 * @author ssianrosalejos
 */
public class viewPayrollPopup extends javax.swing.JFrame {
    int selectedEmpID;
    String inputDate;
    String payslipName;
    private static final String assetsFolder = "/src/MotorPHPayrollApp_CompProg2/Assets/";
    /**
     * Creates new form viewPayroll
     * @throws java.lang.Exception
     */
    public void fetchComponents() throws Exception {
        userNameLabel.setText("Welcome " + Components.fetchUserFirstName());
        userEmpIDLabel.setText(String.valueOf(Components.fetchUserEmpID()));
        weather.setText(Components.getWeatherInfo());
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm:ss a", Locale.getDefault());
        String formattedTime = now.format(formatter);
        localTime.setText(formattedTime);
        DateTimeFormatter dateformatter = DateTimeFormatter.ofPattern("EEEE, MMMM dd, yyyy", Locale.getDefault());
        String formattedDate = now.format(dateformatter);
        localDate.setText(formattedDate);
    }
    
    public void fetchSelectedEmployeeDetails(int e, String l, String f, String s, String PH, String t, String PI) {
        selectedEmpID = e;
        selectedName.setText("Viewing payroll details of " + l + ", " + f);
        selectedEmployeeID.setText("Employee ID: " + e);
        selectedSSS.setText("SSS ID: " + s);
        selectedPhilHealth.setText("PhilHealth ID: " + PH);
        selectedTIN.setText("TIN ID: " + t);
        selectedPagIbig.setText("Pag-Ibig ID: " + PI);
        payslipName = f + " " + l;
        fetchMonthYear(e);
    }
    
    public void fetchMonthYear(int empid) {
        String DB_URL = "jdbc:mysql://localhost:3306/MotorPH";
        String DB_USERNAME = "root";
        String DB_PASSWORD = "";
        int empID = empid;
        
        
        String query = "SELECT DISTINCT month, year FROM attendancerecordv4 WHERE employee_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, empID);

            ResultSet resultSet = preparedStatement.executeQuery();
            Set<String> uniqueRecords = new HashSet<>();

            while (resultSet.next()) {
                int monthNumber = resultSet.getInt("month");
                String year = resultSet.getString("year");

                // Convert month number to month name
                String monthName = Month.of(monthNumber).name();

                // Format month name to capitalize first letter and lowercase the rest
                monthName = monthName.charAt(0) + monthName.substring(1).toLowerCase();

                // Store the unique combination of month and year
                uniqueRecords.add(monthName + " " + year);
            }

            // Print unique records
            for (String record : uniqueRecords) {
                monthYear.addItem(record);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
    }
    
    private void setTime() {
            Timer timer = new Timer(1000, e -> {
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm:ss a", Locale.getDefault());
            String formattedTime = now.format(formatter);
            localTime.setText(formattedTime);
            DateTimeFormatter dateformatter = DateTimeFormatter.ofPattern("EEEE, MMMM dd, yyyy", Locale.getDefault());
            String formattedDate = now.format(dateformatter);
            localDate.setText(formattedDate);
        });
            timer.start();
        }
    
    private void printTextArea() {
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setPrintable(new Printable() {
            public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
                if (pageIndex > 0) {
                    return NO_SUCH_PAGE;
                }
                Graphics2D g2d = (Graphics2D) graphics;
                g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
                payslip.printAll(graphics);
                return PAGE_EXISTS;
            }
        });

        boolean doPrint = job.printDialog();
        if (doPrint) {
            try {
                job.print();
            } catch (PrinterException ex) {
                ex.printStackTrace();
            }
        }
    }
   
    
    public viewPayrollPopup() {
        setTime();
        initComponents();
        

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        userNameLabel = new javax.swing.JLabel();
        userEmpIDLabel = new javax.swing.JLabel();
        dateLabel = new javax.swing.JLabel();
        printButton = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        payslip = new javax.swing.JTextArea();
        viewSalaryButton = new javax.swing.JButton();
        selectedName = new javax.swing.JLabel();
        closeWindow = new javax.swing.JLabel();
        detailsPanel = new javax.swing.JPanel();
        selectedEmployeeID = new javax.swing.JLabel();
        selectedSSS = new javax.swing.JLabel();
        selectedPhilHealth = new javax.swing.JLabel();
        selectedTIN = new javax.swing.JLabel();
        selectedPagIbig = new javax.swing.JLabel();
        localDate = new javax.swing.JLabel();
        localTime = new javax.swing.JLabel();
        weather = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        monthYear = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        userNameLabel.setFont(new java.awt.Font("Helvetica Neue", 1, 36)); // NOI18N
        userNameLabel.setText("userNameLabel");
        jPanel1.add(userNameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        userEmpIDLabel.setForeground(new java.awt.Color(102, 102, 102));
        userEmpIDLabel.setText("userEmpIDLabel");
        jPanel1.add(userEmpIDLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 110, 20));

        dateLabel.setText("Please select the payroll period:");
        jPanel1.add(dateLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, -1, -1));

        printButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/print_unselected.png"))); // NOI18N
        printButton.setToolTipText("Print payslip");
        printButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                printButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                printButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                printButtonMouseExited(evt);
            }
        });
        jPanel1.add(printButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 160, -1, -1));

        payslip.setEditable(false);
        payslip.setColumns(20);
        payslip.setFont(new java.awt.Font("Courier New", 0, 13)); // NOI18N
        payslip.setRows(5);
        payslip.setText("\nSelect the payroll period and click Compute Monthly Salary button \nto generate payslip.");
        jScrollPane1.setViewportView(payslip);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, 590, 310));

        viewSalaryButton.setText("Compute Monthly Salary");
        viewSalaryButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                viewSalaryButtonMouseClicked(evt);
            }
        });
        jPanel1.add(viewSalaryButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 130, -1, -1));

        selectedName.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        selectedName.setText("selectedName");
        jPanel1.add(selectedName, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 100, -1, -1));

        closeWindow.setForeground(new java.awt.Color(102, 102, 102));
        closeWindow.setText("Close window");
        closeWindow.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeWindowMouseClicked(evt);
            }
        });
        jPanel1.add(closeWindow, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 10, -1, -1));

        detailsPanel.setOpaque(false);
        detailsPanel.setLayout(new javax.swing.BoxLayout(detailsPanel, javax.swing.BoxLayout.Y_AXIS));

        selectedEmployeeID.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        selectedEmployeeID.setText("selectedEmployeeID");
        detailsPanel.add(selectedEmployeeID);

        selectedSSS.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        selectedSSS.setText("selectedSSS");
        detailsPanel.add(selectedSSS);

        selectedPhilHealth.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        selectedPhilHealth.setText("selectedPhilHealth");
        detailsPanel.add(selectedPhilHealth);

        selectedTIN.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        selectedTIN.setText("selectedTIN");
        detailsPanel.add(selectedTIN);

        selectedPagIbig.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        selectedPagIbig.setText("selectedPagIbig");
        detailsPanel.add(selectedPagIbig);

        jPanel1.add(detailsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 210, 230, 130));

        localDate.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        localDate.setText("localDate");
        jPanel1.add(localDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 60, -1, -1));

        localTime.setText("localTime");
        jPanel1.add(localTime, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 80, -1, -1));

        weather.setText("weather");
        jPanel1.add(weather, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 40, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/test.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 30, -1, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/rectangle.png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(-50, 10, -1, -1));

        monthYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "" }));
        jPanel1.add(monthYear, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 130, 180, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/backgroundImage_coloredroad.jpeg"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 500));

        setBounds(0, 0, 950, 528);
    }// </editor-fold>//GEN-END:initComponents

    private void closeWindowMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeWindowMouseClicked
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_closeWindowMouseClicked

    private void viewSalaryButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewSalaryButtonMouseClicked
        String selectedItem;
        int month;
        int year;
        String payslipPeriod;
        
        selectedItem = (String) monthYear.getSelectedItem();
        
        String[] parts = selectedItem.split(" ");
        String monthName = parts[0];
        year = Integer.parseInt(parts[1]);
        
        month = Month.valueOf(monthName.toUpperCase()).getValue();
        
        try {
            // TODO add your handling code here:
            Payslip computePay = new Payslip();
            payslip.setText(computePay.computeMonthlySalary(String.valueOf(selectedEmpID), payslipName, month, year, selectedItem));
        } catch (IOException | ParseException ex) {
            Logger.getLogger(viewPayrollPopup.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_viewSalaryButtonMouseClicked

    private void printButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_printButtonMouseClicked
        printTextArea();
    }//GEN-LAST:event_printButtonMouseClicked

    private void printButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_printButtonMouseEntered
        ImageIcon selectedIcon = new ImageIcon(System.getProperty("user.dir") + assetsFolder + "print_selected.png");
        printButton.setIcon(selectedIcon);
    }//GEN-LAST:event_printButtonMouseEntered

    private void printButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_printButtonMouseExited
        ImageIcon selectedIcon = new ImageIcon(System.getProperty("user.dir") + assetsFolder + "print_unselected.png");
        printButton.setIcon(selectedIcon);
    }//GEN-LAST:event_printButtonMouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(viewPayrollPopup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(viewPayrollPopup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(viewPayrollPopup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(viewPayrollPopup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new viewPayrollPopup().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel closeWindow;
    private javax.swing.JLabel dateLabel;
    private javax.swing.JPanel detailsPanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel localDate;
    private javax.swing.JLabel localTime;
    private javax.swing.JComboBox<String> monthYear;
    public javax.swing.JTextArea payslip;
    private javax.swing.JLabel printButton;
    private javax.swing.JLabel selectedEmployeeID;
    private javax.swing.JLabel selectedName;
    private javax.swing.JLabel selectedPagIbig;
    private javax.swing.JLabel selectedPhilHealth;
    private javax.swing.JLabel selectedSSS;
    private javax.swing.JLabel selectedTIN;
    private javax.swing.JLabel userEmpIDLabel;
    private javax.swing.JLabel userNameLabel;
    private javax.swing.JButton viewSalaryButton;
    public javax.swing.JLabel weather;
    // End of variables declaration//GEN-END:variables
}
