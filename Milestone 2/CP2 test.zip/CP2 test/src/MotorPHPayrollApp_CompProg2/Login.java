/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MotorPHPayrollApp_CompProg2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author ssianrosalejos
 */
public class Login {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/MotorPH";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "";

    public boolean verifyLogin(int empID, String password) {
        boolean loginSuccessful = false;

        String query = "SELECT * FROM login WHERE employee_id = ? AND password = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Set the parameters for the query
            preparedStatement.setInt(1, empID);
            preparedStatement.setString(2, password);

            // Execute the query
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                // Check if a matching record is found
                if (resultSet.next()) {
                    loginSuccessful = true;
                }
            }

        } catch (SQLException e) {
            // Handle SQLException as needed
            
        }

        return loginSuccessful;
    }

}
