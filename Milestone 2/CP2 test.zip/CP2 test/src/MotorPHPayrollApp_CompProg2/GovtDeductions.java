package MotorPHPayrollApp_CompProg2;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GovtDeductions {

	// Method for calculating Social Security System (SSS) contribution
	public static double sss(double monthlyGrossSalary) {
            String DB_URL = "jdbc:mysql://localhost:3306/MotorPH"; // Replace with your database URL
            String DB_USERNAME = "root"; // Replace with your database username
            String DB_PASSWORD = ""; // Replace with your database password

            double sssCon = 0;

            // Check if the gross monthly salary is greater than or equal to 24,750
            if (monthlyGrossSalary >= 24750) {
                sssCon = 1125;
            } else {
                String query = "SELECT contribution FROM sss_contribution1 WHERE ? BETWEEN `from` AND `to`";

                try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
                     PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                    // Set the monthly gross salary parameter
                    preparedStatement.setDouble(1, monthlyGrossSalary);

                    // Execute the query
                    ResultSet resultSet = preparedStatement.executeQuery();

                    // Check if a result was returned and extract the contribution
                    if (resultSet.next()) {
                        sssCon = resultSet.getDouble("contribution");
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            return sssCon;
        }
	// Method for calculating PhilHealth contribution
	public static double philHealth(double monthlyGrossSalary) {
		// Set the premium rate
		double premiumRate = 0.03;
		double premium;
		double philHealthEmpShare;

		// Calculate the premium based on the gross salary
		if (monthlyGrossSalary >= 60000) {
			premium = 1800;
		} else if (monthlyGrossSalary > 10000) {
			premium = monthlyGrossSalary * premiumRate;
		} else {
			premium = 300;
		}

		// Calculate the employee's share of the PhilHealth contribution
		philHealthEmpShare = premium * 0.50;

		// Format the result to two decimal places and round up
		DecimalFormat decFormat = new DecimalFormat("0.00");
		decFormat.setRoundingMode(RoundingMode.UP);


		// Return the employee's share of the PhilHealth contribution
		return philHealthEmpShare;

	}

	// Method for calculating Pag-ibig contribution
	public static double pagIbig(double monthlyGrossSalary) {
		double pagIbigEmpShare;


		// Calculate the employee's share of the Pag-ibig contribution based on the gross salary
		if (monthlyGrossSalary > 1500) {
			pagIbigEmpShare = monthlyGrossSalary * .02;
			if (pagIbigEmpShare > 100) {
				pagIbigEmpShare = 100;
			}

		}else if (monthlyGrossSalary > 1000) {
			pagIbigEmpShare = monthlyGrossSalary * .01;

		} else {
			pagIbigEmpShare = 0;
		}


		// Return the employee's share of the Pag-ibig contribution
		return pagIbigEmpShare;

	}
}