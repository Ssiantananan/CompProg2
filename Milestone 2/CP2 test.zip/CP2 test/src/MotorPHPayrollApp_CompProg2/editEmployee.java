/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package MotorPHPayrollApp_CompProg2;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 *
 * @author ssianrosalejos
 */
public class editEmployee extends javax.swing.JFrame {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/MotorPH";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "";
    private static final String assetsFolder = "/src/MotorPHPayrollApp_CompProg2/Assets/";
    private int fromEmpTable;
    /**
     * Creates new form editEmployee
     * @throws java.lang.Exception
     */
    public void fetchComponents() throws Exception {
        userNameLabel.setText("Welcome " + Components.fetchUserFirstName());
        userEmpIDLabel.setText(String.valueOf(Components.fetchUserEmpID()));
        weather.setText(Components.getWeatherInfo());
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm:ss a", Locale.getDefault());
        String formattedTime = now.format(formatter);
        localTime.setText(formattedTime);
        DateTimeFormatter dateformatter = DateTimeFormatter.ofPattern("EEEE, MMMM dd, yyyy", Locale.getDefault());
        String formattedDate = now.format(dateformatter);
        localDate.setText(formattedDate);
    }
    
    private void setTime() {
            Timer timer = new Timer(1000, e -> {
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm:ss a", Locale.getDefault());
            String formattedTime = now.format(formatter);
            localTime.setText(formattedTime);
            DateTimeFormatter dateformatter = DateTimeFormatter.ofPattern("EEEE, MMMM dd, yyyy", Locale.getDefault());
            String formattedDate = now.format(dateformatter);
            localDate.setText(formattedDate);
        });
            timer.start();
        }
    
    public void updateFields(String selectedEmpID) {
        int EmpID;
        
        String empIDText = selectedEmpID;
        EmpID = Integer.parseInt(empIDText);

        String query = "SELECT * FROM motorph_employee_data WHERE employee_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Set the parameter for the query
            preparedStatement.setInt(1, EmpID);

            // Execute the query
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                boolean found = false;
                if (resultSet.next()) {
                    found = true;
                    empID.setText(resultSet.getString("employee_id"));
                    lastName.setText(resultSet.getString("last_name"));
                    lastName.setNextFocusableComponent(firstName);
                    firstName.setText(resultSet.getString("first_name"));
                    firstName.setNextFocusableComponent(birthday);
                    birthday.setText(resultSet.getString("birthday"));
                    birthday.setNextFocusableComponent(phone);
                    phone.setText(resultSet.getString("phone"));
                    phone.setNextFocusableComponent(status);
                    if ("Regular".equals(resultSet.getString("status"))){
                        status.setSelectedIndex(1);
                    } else {
                        status.setSelectedIndex(0);
                    }
                    status.setNextFocusableComponent(supervisor);
                    supervisor.setText(resultSet.getString("supervisor"));
                    supervisor.setNextFocusableComponent(position);
                    position.setText(resultSet.getString("position"));
                    position.setNextFocusableComponent(sss);
                    sss.setText(resultSet.getString("SSS"));
                    sss.setNextFocusableComponent(philhealth);
                    philhealth.setText(resultSet.getString("philhealth"));
                    philhealth.setNextFocusableComponent(tin);
                    tin.setText(resultSet.getString("TIN"));
                    tin.setNextFocusableComponent(pagibig);
                    pagibig.setText(resultSet.getString("pagibig"));
                    pagibig.setNextFocusableComponent(lastName);
                    empDetails.setVisible(true);
                }

                if (!found) {
                    JOptionPane.showMessageDialog(this, "Employee not found. Please enter a valid Employee Number.", "Invalid EmpID", JOptionPane.ERROR_MESSAGE);
                }
            }

            } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void setEmpTable (int fromemptable) {
        fromEmpTable = fromemptable;
    }
    
    public editEmployee() {
        setTime();
        initComponents();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        userNameLabel = new javax.swing.JLabel();
        userEmpIDLabel = new javax.swing.JLabel();
        saveButton = new javax.swing.JLabel();
        discardButton = new javax.swing.JLabel();
        empDetails = new javax.swing.JPanel();
        phoneLabel = new javax.swing.JLabel();
        birthdayLabel = new javax.swing.JLabel();
        statusLabel = new javax.swing.JLabel();
        supervisorLabel = new javax.swing.JLabel();
        positionLabel = new javax.swing.JLabel();
        lastNameLabel = new javax.swing.JLabel();
        position = new javax.swing.JTextField();
        lastName = new javax.swing.JTextField();
        birthday = new javax.swing.JTextField();
        phone = new javax.swing.JTextField();
        supervisor = new javax.swing.JTextField();
        sssLabel = new javax.swing.JLabel();
        sss = new javax.swing.JTextField();
        philhealthLabel = new javax.swing.JLabel();
        philhealth = new javax.swing.JTextField();
        tinLabel = new javax.swing.JLabel();
        tin = new javax.swing.JTextField();
        pagibigLabel = new javax.swing.JLabel();
        pagibig = new javax.swing.JTextField();
        firstNameLabe = new javax.swing.JLabel();
        firstName = new javax.swing.JTextField();
        status = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        empID = new javax.swing.JLabel();
        localDate = new javax.swing.JLabel();
        localTime = new javax.swing.JLabel();
        weather = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setSize(new java.awt.Dimension(950, 500));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        userNameLabel.setFont(new java.awt.Font("Helvetica Neue", 1, 36)); // NOI18N
        userNameLabel.setText("userNameLabel");
        jPanel1.add(userNameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        userEmpIDLabel.setForeground(new java.awt.Color(102, 102, 102));
        userEmpIDLabel.setText("userEmpIDLabel");
        jPanel1.add(userEmpIDLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, -1));

        saveButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/saveButton_unselected.png"))); // NOI18N
        saveButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                saveButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                saveButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                saveButtonMouseExited(evt);
            }
        });
        jPanel1.add(saveButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 410, -1, -1));

        discardButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/discard_unselected.png"))); // NOI18N
        discardButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                discardButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                discardButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                discardButtonMouseExited(evt);
            }
        });
        jPanel1.add(discardButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 410, -1, -1));

        empDetails.setBackground(new java.awt.Color(241, 241, 241));
        empDetails.setOpaque(false);

        phoneLabel.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        phoneLabel.setText("Phone Number");

        birthdayLabel.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        birthdayLabel.setText("Birthday");

        statusLabel.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        statusLabel.setText("Status");

        supervisorLabel.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        supervisorLabel.setText("Supervisor");

        positionLabel.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        positionLabel.setText("Position");

        lastNameLabel.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        lastNameLabel.setText("Last Name");

        position.setText("position");
        position.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                positionActionPerformed(evt);
            }
        });

        lastName.setText("last name");
        lastName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lastNameActionPerformed(evt);
            }
        });

        birthday.setText("birthday");
        birthday.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                birthdayActionPerformed(evt);
            }
        });

        phone.setText("phone");
        phone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phoneActionPerformed(evt);
            }
        });

        supervisor.setText("supervisor");
        supervisor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                supervisorActionPerformed(evt);
            }
        });

        sssLabel.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        sssLabel.setText("SSS");

        sss.setText("SSS ID");
        sss.setPreferredSize(new java.awt.Dimension(161, 20));
        sss.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sssActionPerformed(evt);
            }
        });

        philhealthLabel.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        philhealthLabel.setText("PhilHealth");

        philhealth.setText("PhilHealth ID");
        philhealth.setPreferredSize(new java.awt.Dimension(161, 20));
        philhealth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                philhealthActionPerformed(evt);
            }
        });

        tinLabel.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        tinLabel.setText("TIN");

        tin.setText("TIN ID");
        tin.setPreferredSize(new java.awt.Dimension(161, 20));

        pagibigLabel.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        pagibigLabel.setText("PagIbig");

        pagibig.setText("PagIbig ID");
        pagibig.setPreferredSize(new java.awt.Dimension(161, 20));

        firstNameLabe.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        firstNameLabe.setText("First Name");

        firstName.setText("first name");
        firstName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                firstNameActionPerformed(evt);
            }
        });

        status.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Probationary", "Regular" }));
        status.setSelectedItem("");
        status.setPreferredSize(new java.awt.Dimension(161, 20));

        javax.swing.GroupLayout empDetailsLayout = new javax.swing.GroupLayout(empDetails);
        empDetails.setLayout(empDetailsLayout);
        empDetailsLayout.setHorizontalGroup(
            empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(empDetailsLayout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addGroup(empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(empDetailsLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(firstNameLabe)
                            .addComponent(birthdayLabel))
                        .addGap(18, 18, 18)
                        .addGroup(empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(birthday)
                            .addComponent(firstName)))
                    .addGroup(empDetailsLayout.createSequentialGroup()
                        .addComponent(phoneLabel)
                        .addGap(18, 18, 18)
                        .addComponent(phone))
                    .addGroup(empDetailsLayout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addComponent(statusLabel)
                        .addGap(18, 18, 18)
                        .addComponent(status, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(empDetailsLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(supervisorLabel)
                        .addGap(18, 18, 18)
                        .addComponent(supervisor))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, empDetailsLayout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(positionLabel)
                        .addGap(18, 18, 18)
                        .addComponent(position))
                    .addGroup(empDetailsLayout.createSequentialGroup()
                        .addGap(0, 29, Short.MAX_VALUE)
                        .addComponent(lastNameLabel)
                        .addGap(17, 17, 17)
                        .addComponent(lastName, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(62, 62, 62)
                .addGroup(empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(empDetailsLayout.createSequentialGroup()
                        .addComponent(philhealthLabel)
                        .addGap(52, 52, 52)
                        .addComponent(philhealth, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(empDetailsLayout.createSequentialGroup()
                        .addComponent(tinLabel)
                        .addGap(97, 97, 97)
                        .addComponent(tin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(empDetailsLayout.createSequentialGroup()
                        .addComponent(pagibigLabel)
                        .addGap(68, 68, 68)
                        .addComponent(pagibig, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(empDetailsLayout.createSequentialGroup()
                        .addComponent(sssLabel)
                        .addGap(93, 93, 93)
                        .addComponent(sss, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(47, 47, 47))
        );
        empDetailsLayout.setVerticalGroup(
            empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(empDetailsLayout.createSequentialGroup()
                .addGroup(empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(empDetailsLayout.createSequentialGroup()
                        .addGroup(empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(empDetailsLayout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(lastNameLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(firstNameLabe)
                                    .addComponent(firstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(lastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(birthday, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(birthdayLabel))
                        .addGap(7, 7, 7)
                        .addGroup(empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(phone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(phoneLabel)))
                    .addGroup(empDetailsLayout.createSequentialGroup()
                        .addGroup(empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(sssLabel)
                            .addComponent(sss, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(philhealthLabel)
                            .addComponent(philhealth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tinLabel)
                            .addComponent(tin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pagibigLabel)
                            .addComponent(pagibig, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(6, 6, 6)
                .addGroup(empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(statusLabel)
                    .addComponent(status, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(supervisorLabel)
                    .addComponent(supervisor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(empDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(position, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(positionLabel))
                .addGap(31, 31, 31))
        );

        jPanel1.add(empDetails, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, 810, 240));

        jPanel3.setOpaque(false);
        jPanel3.setPreferredSize(new java.awt.Dimension(100, 200));

        jLabel2.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        jLabel2.setText("Editing Employee ID:");

        empID.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        empID.setText("employee ID");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(empID, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(empID))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 350, 50));

        localDate.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        localDate.setText("localDate");
        jPanel1.add(localDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 60, -1, -1));

        localTime.setText("localTime");
        jPanel1.add(localTime, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 80, -1, -1));

        weather.setText("weather");
        jPanel1.add(weather, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 40, -1, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/test.png"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 30, -1, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/rectangle.png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(-50, 10, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/backgroundImage_coloredroad.jpeg"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 500));

        setSize(new java.awt.Dimension(950, 528));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void positionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_positionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_positionActionPerformed

    private void lastNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lastNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lastNameActionPerformed

    private void birthdayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_birthdayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_birthdayActionPerformed

    private void phoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_phoneActionPerformed

    private void supervisorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_supervisorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_supervisorActionPerformed

    private void saveButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_saveButtonMouseEntered
        // TODO add your handling code here:
        ImageIcon selectedIcon = new ImageIcon(System.getProperty("user.dir") + assetsFolder + "saveButton_selected.png");
        saveButton.setIcon(selectedIcon);
    }//GEN-LAST:event_saveButtonMouseEntered

    private void discardButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_discardButtonMouseEntered
        // TODO add your handling code here:
        ImageIcon selectedIcon = new ImageIcon(System.getProperty("user.dir") + assetsFolder + "discard_selected.png");
        discardButton.setIcon(selectedIcon);
    }//GEN-LAST:event_discardButtonMouseEntered

    private void saveButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_saveButtonMouseExited
        // TODO add your handling code here:
        ImageIcon selectedIcon = new ImageIcon(System.getProperty("user.dir") + assetsFolder + "saveButton_unselected.png");
        saveButton.setIcon(selectedIcon);
    }//GEN-LAST:event_saveButtonMouseExited

    private void discardButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_discardButtonMouseExited
        // TODO add your handling code here:
        ImageIcon selectedIcon = new ImageIcon(System.getProperty("user.dir") + assetsFolder + "discard_unselected.png");
        discardButton.setIcon(selectedIcon);
    }//GEN-LAST:event_discardButtonMouseExited

    private void sssActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sssActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sssActionPerformed

    private void philhealthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_philhealthActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_philhealthActionPerformed

    private void firstNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_firstNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_firstNameActionPerformed

    private void saveButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_saveButtonMouseClicked

        // Confirm dialogue box
        int reply = JOptionPane.showConfirmDialog(null, "Please confirm all information entered is correct.", "Confirm", JOptionPane.YES_NO_OPTION);
        if (reply == JOptionPane.YES_OPTION) {
        
        String query = "UPDATE motorph_employee_data SET last_name = ?, first_name = ?, birthday = ?, phone = ?, status = ?, supervisor = ?, position = ?, SSS = ?, philhealth = ?, TIN = ?, pagibig = ? WHERE employee_id = ?";
        
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Set parameters for the update query
            preparedStatement.setString(1, lastName.getText());
            preparedStatement.setString(2, firstName.getText());
            preparedStatement.setString(3, birthday.getText());
            preparedStatement.setString(4, phone.getText());
            preparedStatement.setString(5, (String) status.getSelectedItem());
            preparedStatement.setString(6, supervisor.getText());
            preparedStatement.setString(7, position.getText());
            preparedStatement.setString(8, sss.getText());
            preparedStatement.setString(9, philhealth.getText());
            preparedStatement.setString(10, tin.getText());
            preparedStatement.setString(11, pagibig.getText());
            preparedStatement.setInt(12, Integer.parseInt(empID.getText()));
            // Execute the update statement
            preparedStatement.executeUpdate();

            if (fromEmpTable == 1){
                employeeTable empTable = new employeeTable();
                empTable.setVisible(false);
                try {
                empTable.fetchComponents();
                } catch (Exception ex) {
                    Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
                }
                empTable.setVisible(true);
                this.setVisible(false);
                JOptionPane.showMessageDialog(null, "Saved changes.");
            } else {
            JOptionPane.showMessageDialog(null, "Saved changes.");
            this.setVisible(false);
            }
            

        } catch (SQLException e) {
        }   catch (IOException ex) {
                Logger.getLogger(editEmployee.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_saveButtonMouseClicked

    private void discardButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_discardButtonMouseClicked
        int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to discard changes?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (reply == JOptionPane.YES_OPTION) {
            if (fromEmpTable == 1) {
                try {
                    employeeTable empTable1 = new employeeTable();
                    empTable1.setVisible(false);
                    try {
                        empTable1.fetchComponents();
                    } catch (Exception ex) {
                        Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    empTable1.setVisible(true);
                    this.setVisible(false);
                } catch (IOException ex) {
                    Logger.getLogger(editEmployee.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            this.setVisible(false);
        }
    }//GEN-LAST:event_discardButtonMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(editEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(editEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(editEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(editEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new editEmployee().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField birthday;
    private javax.swing.JLabel birthdayLabel;
    private javax.swing.JLabel discardButton;
    private javax.swing.JPanel empDetails;
    private javax.swing.JLabel empID;
    private javax.swing.JTextField firstName;
    private javax.swing.JLabel firstNameLabe;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTextField lastName;
    private javax.swing.JLabel lastNameLabel;
    private javax.swing.JLabel localDate;
    private javax.swing.JLabel localTime;
    private javax.swing.JTextField pagibig;
    private javax.swing.JLabel pagibigLabel;
    private javax.swing.JTextField philhealth;
    private javax.swing.JLabel philhealthLabel;
    private javax.swing.JTextField phone;
    private javax.swing.JLabel phoneLabel;
    private javax.swing.JTextField position;
    private javax.swing.JLabel positionLabel;
    private javax.swing.JLabel saveButton;
    private javax.swing.JTextField sss;
    private javax.swing.JLabel sssLabel;
    private javax.swing.JComboBox<String> status;
    private javax.swing.JLabel statusLabel;
    private javax.swing.JTextField supervisor;
    private javax.swing.JLabel supervisorLabel;
    private javax.swing.JTextField tin;
    private javax.swing.JLabel tinLabel;
    private javax.swing.JLabel userEmpIDLabel;
    private javax.swing.JLabel userNameLabel;
    public javax.swing.JLabel weather;
    // End of variables declaration//GEN-END:variables
}
