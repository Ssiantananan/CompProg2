/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package MotorPHPayrollApp_CompProg2;

import java.awt.Cursor;
import java.util.List;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 *
 * @author ssianrosalejos
 */
public class employeeTable extends javax.swing.JFrame {
    int selectedEmployeeID;
    String selectedFirstName;
    String selectedLastName;
    String selectedSSS;
    String selectedPhilHealth;
    String selectedPagIbig;
    String selectedTIN;
    private static final String DB_URL = "jdbc:mysql://localhost:3306/MotorPH";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "";
    private static final String assetsFolder = "/src/MotorPHPayrollApp_CompProg2/Assets/";
    /**
     * Creates new form employeeTable
     * @throws java.lang.Exception
     */
    public void fetchComponents() throws Exception {
        userNameLabel.setText("Welcome " + Components.fetchUserFirstName());
        userEmpIDLabel.setText(String.valueOf(Components.fetchUserEmpID()));
        weather.setText(Components.getWeatherInfo());
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm:ss a", Locale.getDefault());
        String formattedTime = now.format(formatter);
        localTime.setText(formattedTime);
        DateTimeFormatter dateformatter = DateTimeFormatter.ofPattern("EEEE, MMMM dd, yyyy", Locale.getDefault());
        String formattedDate = now.format(dateformatter);
        localDate.setText(formattedDate);
    }
    private void setTime() {
            Timer timer = new Timer(1000, e -> {
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm:ss a", Locale.getDefault());
            String formattedTime = now.format(formatter);
            localTime.setText(formattedTime);
            DateTimeFormatter dateformatter = DateTimeFormatter.ofPattern("EEEE, MMMM dd, yyyy", Locale.getDefault());
            String formattedDate = now.format(dateformatter);
            localDate.setText(formattedDate);
        });
            timer.start();
        }
    
    public employeeTable() throws IOException {
        setTime();
        initComponents();
        tableUpdater();
    }
    
    public final void tableUpdater() throws IOException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            String query = "SELECT employee_id, last_name, first_name, SSS, philhealth, TIN, pagibig FROM motorph_employee_data";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                // Get column count
                int columnCount = resultSet.getMetaData().getColumnCount();

                // Get column names
                String[] desiredColumns = new String[columnCount];
                for (int i = 0; i < columnCount; i++) {
                    desiredColumns[i] = resultSet.getMetaData().getColumnName(i + 1);
                }

                // Prepare data for the desired columns
                List<Object[]> data = new ArrayList<>();
                while (resultSet.next()) {
                    Object[] rowData = new Object[columnCount];
                    for (int i = 0; i < columnCount; i++) {
                        rowData[i] = resultSet.getObject(i + 1);
                    }
                    data.add(rowData);
                }

                // Convert List<Object[]> to Object[][]
                Object[][] tableData = new Object[data.size()][columnCount];
                for (int i = 0; i < data.size(); i++) {
                    tableData[i] = data.get(i);
                }

                // Set the model with the desired columns and data
                DefaultTableModel model = (DefaultTableModel) employeeTable.getModel();
                model.setDataVector(tableData, desiredColumns);

                // Optionally enable auto sorting
                // employeeTable.setAutoCreateRowSorter(true);
            }
        } catch (SQLException ex) {
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        employeeTablePanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        employeeTable = new javax.swing.JTable();
        userNameLabel = new javax.swing.JLabel();
        userEmpIDLabel = new javax.swing.JLabel();
        mainMenu = new javax.swing.JLabel();
        logout = new javax.swing.JLabel();
        instruction = new javax.swing.JLabel();
        selectedEmpPanel = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        empName = new javax.swing.JLabel();
        viewEmployee = new javax.swing.JLabel();
        editButton = new javax.swing.JLabel();
        deleteButton = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        addEmployeeButton = new javax.swing.JLabel();
        searchEmployeeButton = new javax.swing.JLabel();
        localDate = new javax.swing.JLabel();
        localTime = new javax.swing.JLabel();
        weather = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Employee Database");
        setSize(new java.awt.Dimension(950, 500));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        employeeTablePanel.setPreferredSize(new java.awt.Dimension(950, 500));
        employeeTablePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        employeeTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "null", "null", "null", "null", "null", "null", "null"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return false;
            }
        });
        employeeTable.setOpaque(false);
        employeeTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                employeeTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(employeeTable);

        employeeTablePanel.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 630, 290));

        userNameLabel.setFont(new java.awt.Font("Helvetica Neue", 1, 36)); // NOI18N
        userNameLabel.setText("userNameLabel");
        employeeTablePanel.add(userNameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        userEmpIDLabel.setForeground(new java.awt.Color(102, 102, 102));
        userEmpIDLabel.setText("userEmpIDLabel");
        employeeTablePanel.add(userEmpIDLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, -1));

        mainMenu.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        mainMenu.setForeground(new java.awt.Color(0, 153, 204));
        mainMenu.setText("Main Menu");
        mainMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mainMenuMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                mainMenuMouseEntered(evt);
            }
        });
        employeeTablePanel.add(mainMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 10, -1, -1));

        logout.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        logout.setForeground(new java.awt.Color(102, 102, 102));
        logout.setText("Logout");
        logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                logoutMouseEntered(evt);
            }
        });
        employeeTablePanel.add(logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 10, -1, -1));

        instruction.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        instruction.setText("Select an employee and click View Employee below to view payroll details:");
        employeeTablePanel.add(instruction, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        selectedEmpPanel.setOpaque(false);
        selectedEmpPanel.setVisible(false);
        selectedEmpPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setOpaque(false);

        empName.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        empName.setText("empName");
        empName.setPreferredSize(new java.awt.Dimension(200, 17));
        jPanel2.add(empName);

        viewEmployee.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/viewButton.png"))); // NOI18N
        viewEmployee.setToolTipText("View Employee");
        viewEmployee.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                viewEmployeeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                viewEmployeeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                viewEmployeeMouseExited(evt);
            }
        });
        jPanel2.add(viewEmployee);

        editButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/editButton.png"))); // NOI18N
        editButton.setToolTipText("Edit Employee");
        editButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                editButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                editButtonMouseExited(evt);
            }
        });
        jPanel2.add(editButton);

        deleteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/deleteButton.png"))); // NOI18N
        deleteButton.setToolTipText("Delete Employee");
        deleteButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                deleteButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                deleteButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                deleteButtonMouseExited(evt);
            }
        });
        jPanel2.add(deleteButton);

        selectedEmpPanel.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 350, 50));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/rectangle390x70.png"))); // NOI18N
        selectedEmpPanel.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        employeeTablePanel.add(selectedEmpPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 420, 390, 70));

        jPanel1.setOpaque(false);
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 10));

        addEmployeeButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/addEmployeeButton_unselected.png"))); // NOI18N
        addEmployeeButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addEmployeeButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                addEmployeeButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                addEmployeeButtonMouseExited(evt);
            }
        });
        jPanel1.add(addEmployeeButton);

        searchEmployeeButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/searchEmployeeButton_unselected.png"))); // NOI18N
        searchEmployeeButton.setAlignmentY(0.0F);
        searchEmployeeButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchEmployeeButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                searchEmployeeButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                searchEmployeeButtonMouseExited(evt);
            }
        });
        jPanel1.add(searchEmployeeButton);

        employeeTablePanel.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 120, 240, 220));

        localDate.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        localDate.setText("localDate");
        employeeTablePanel.add(localDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 60, -1, -1));

        localTime.setText("localTime");
        employeeTablePanel.add(localTime, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 80, -1, -1));

        weather.setText("weather");
        employeeTablePanel.add(weather, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 40, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/test.png"))); // NOI18N
        employeeTablePanel.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 30, -1, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/rectangle.png"))); // NOI18N
        employeeTablePanel.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(-50, 10, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MotorPHPayrollApp_CompProg2/Assets/backgroundImage_coloredroad.jpeg"))); // NOI18N
        employeeTablePanel.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(employeeTablePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 500));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void employeeTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_employeeTableMouseClicked
        int selectedRow = employeeTable.getSelectedRow();
    if (selectedRow != -1) {
        selectedEmployeeID = Integer.parseInt(employeeTable.getValueAt(selectedRow, 0).toString());
        selectedLastName = employeeTable.getValueAt(selectedRow, 1).toString();
        selectedFirstName = employeeTable.getValueAt(selectedRow, 2).toString();
        selectedSSS = employeeTable.getValueAt(selectedRow, 3).toString();
        selectedPhilHealth = employeeTable.getValueAt(selectedRow, 4).toString();
        selectedTIN = employeeTable.getValueAt(selectedRow, 5).toString();
        selectedPagIbig = employeeTable.getValueAt(selectedRow, 6).toString();
        empName.setText(selectedLastName + ", " + selectedFirstName);
        selectedEmpPanel.setVisible(true);
    }
    }//GEN-LAST:event_employeeTableMouseClicked

    private void mainMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainMenuMouseClicked
        Menu menu = new Menu();
        try {
            menu.fetchComponents();
        } catch (Exception ex) {
            Logger.getLogger(employeeTable.class.getName()).log(Level.SEVERE, null, ex);
        }
        menu.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_mainMenuMouseClicked

    private void mainMenuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainMenuMouseEntered
        mainMenu.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_mainMenuMouseEntered

    private void logoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseClicked
        System.exit(0);
    }//GEN-LAST:event_logoutMouseClicked

    private void logoutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseEntered
        logout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_logoutMouseEntered

    private void addEmployeeButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addEmployeeButtonMouseClicked
        // TODO add your handling code here:
        addEmployee add = new addEmployee();
        try {
            add.fetchComponents();
        } catch (Exception ex) {
            Logger.getLogger(employeeTable.class.getName()).log(Level.SEVERE, null, ex);
        }
        add.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_addEmployeeButtonMouseClicked

    private void addEmployeeButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addEmployeeButtonMouseEntered
        // TODO add your handling code here:
        ImageIcon selectedIcon = new ImageIcon(System.getProperty("user.dir") + assetsFolder + "addEmployeeButton_selected.png");
        addEmployeeButton.setIcon(selectedIcon);
    }//GEN-LAST:event_addEmployeeButtonMouseEntered

    private void addEmployeeButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addEmployeeButtonMouseExited
        // TODO add your handling code here:
        ImageIcon selectedIcon = new ImageIcon(System.getProperty("user.dir") + assetsFolder + "addEmployeeButton_unselected.png");
        addEmployeeButton.setIcon(selectedIcon);
    }//GEN-LAST:event_addEmployeeButtonMouseExited

    private void viewEmployeeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewEmployeeMouseClicked
        // TODO add your handling code here:
        viewPayrollPopup viewpayroll = new viewPayrollPopup();
        try {
            viewpayroll.fetchComponents();
            viewpayroll.fetchSelectedEmployeeDetails(selectedEmployeeID, selectedLastName, selectedFirstName, selectedSSS, selectedPhilHealth, selectedTIN, selectedPagIbig);
        } catch (Exception ex) {
            Logger.getLogger(employeeTable.class.getName()).log(Level.SEVERE, null, ex);
        }
        viewpayroll.setVisible(true);
    }//GEN-LAST:event_viewEmployeeMouseClicked

    private void editButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editButtonMouseClicked
        editEmployee edit = new editEmployee();
        try {
            edit.fetchComponents();
        } catch (Exception ex) {
            Logger.getLogger(employeeTable.class.getName()).log(Level.SEVERE, null, ex);
        }
        edit.setEmpTable(1);
        edit.updateFields(String.valueOf(selectedEmployeeID));
        edit.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_editButtonMouseClicked

    private void deleteButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteButtonMouseClicked
            int reply = JOptionPane.showConfirmDialog(null, "Are you you want to delete " + selectedEmployeeID + " " + selectedFirstName + " " + selectedLastName + "?\nThis action cannot be undone.", "Confirm", JOptionPane.YES_NO_OPTION);
            if (reply == JOptionPane.YES_OPTION) {
                String query = "DELETE FROM motorph_employee_data WHERE employee_id = ?";
        
                try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
                PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                    // Set the employee ID parameter
                    preparedStatement.setInt(1, selectedEmployeeID);

                    // Execute the delete statement
                    int rowsAffected = preparedStatement.executeUpdate();

                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(null, "Record deleted.");
                        try {
                            tableUpdater();
                        } catch (IOException ex) {
                            Logger.getLogger(employeeTable.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Record not found or couldn't be deleted.", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null, "An error occurred while deleting the record.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
    }//GEN-LAST:event_deleteButtonMouseClicked

    private void viewEmployeeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewEmployeeMouseEntered
        ImageIcon selectedIcon = new ImageIcon(System.getProperty("user.dir") + assetsFolder + "viewButton_selected.png");
        viewEmployee.setIcon(selectedIcon);
    }//GEN-LAST:event_viewEmployeeMouseEntered

    private void viewEmployeeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewEmployeeMouseExited
        ImageIcon selectedIcon = new ImageIcon(System.getProperty("user.dir") + assetsFolder + "viewButton.png");
        viewEmployee.setIcon(selectedIcon);
    }//GEN-LAST:event_viewEmployeeMouseExited

    private void editButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editButtonMouseEntered
        ImageIcon selectedIcon = new ImageIcon(System.getProperty("user.dir") + assetsFolder + "editButton_selected.png");
        editButton.setIcon(selectedIcon);
    }//GEN-LAST:event_editButtonMouseEntered

    private void editButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editButtonMouseExited
        ImageIcon selectedIcon = new ImageIcon(System.getProperty("user.dir") + assetsFolder + "editButton.png");
        editButton.setIcon(selectedIcon);
    }//GEN-LAST:event_editButtonMouseExited

    private void deleteButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteButtonMouseEntered
        ImageIcon selectedIcon = new ImageIcon(System.getProperty("user.dir") + assetsFolder + "deleteButton_selected.png");
        deleteButton.setIcon(selectedIcon);
    }//GEN-LAST:event_deleteButtonMouseEntered

    private void deleteButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteButtonMouseExited
        ImageIcon selectedIcon = new ImageIcon(System.getProperty("user.dir") + assetsFolder + "deleteButton.png");
        deleteButton.setIcon(selectedIcon);
    }//GEN-LAST:event_deleteButtonMouseExited

    private void searchEmployeeButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchEmployeeButtonMouseClicked
        // TODO add your handling code here:
        searchEmployee search = new searchEmployee();
        try {
            search.fetchComponents();
        } catch (Exception ex) {
            Logger.getLogger(employeeTable.class.getName()).log(Level.SEVERE, null, ex);
        }
        search.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_searchEmployeeButtonMouseClicked

    private void searchEmployeeButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchEmployeeButtonMouseEntered
        ImageIcon selectedIcon = new ImageIcon(System.getProperty("user.dir") + assetsFolder + "searchEmployeeButton_selected.png");
        searchEmployeeButton.setIcon(selectedIcon);
    }//GEN-LAST:event_searchEmployeeButtonMouseEntered

    private void searchEmployeeButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchEmployeeButtonMouseExited
        // TODO add your handling code here:
        ImageIcon selectedIcon = new ImageIcon(System.getProperty("user.dir") + assetsFolder + "searchEmployeeButton_unselected.png");
        searchEmployeeButton.setIcon(selectedIcon);
    }//GEN-LAST:event_searchEmployeeButtonMouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(employeeTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(employeeTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(employeeTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(employeeTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    new employeeTable().setVisible(true);
                } catch (IOException ex) {
                    java.util.logging.Logger.getLogger(employeeTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel addEmployeeButton;
    private javax.swing.JLabel deleteButton;
    private javax.swing.JLabel editButton;
    private javax.swing.JLabel empName;
    private javax.swing.JTable employeeTable;
    private javax.swing.JPanel employeeTablePanel;
    private javax.swing.JLabel instruction;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel localDate;
    private javax.swing.JLabel localTime;
    private javax.swing.JLabel logout;
    private javax.swing.JLabel mainMenu;
    private javax.swing.JLabel searchEmployeeButton;
    private javax.swing.JPanel selectedEmpPanel;
    private javax.swing.JLabel userEmpIDLabel;
    private javax.swing.JLabel userNameLabel;
    private javax.swing.JLabel viewEmployee;
    public javax.swing.JLabel weather;
    // End of variables declaration//GEN-END:variables
}
