/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MotorPHPayrollApp_CompProg2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.Date;
import java.io.IOException;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;


/**
 *
 * @author ssianrosalejos
 */
public class Payslip {
    public int payPeriodStart;
    public int payPeriodEnd;
    public float deductions;
    public float allowances;
    public float netSalary;
    String payslipBasicSalary;
    String payslipRiceSubsidy;
    String payslipPhoneAllowance;
    String payslipClothingAllowance;
    String payslipGrossSalary;
    String payslipDeductions;
    String payslipNetSalary;
    String payslipMonthYear;
    String payslipNamePrint;
    String payslipEmpIDPrint;
    double riceSubsidy;
    double phoneAllowance;
    double clothingAllowance;
    
    

    
    public String computeMonthlySalary(String inputEmpId, String payslipName, int month, int year, String period) throws IOException, ParseException {

                String DB_URL = "jdbc:mysql://localhost:3306/MotorPH";
                String DB_USERNAME = "root";
                String DB_PASSWORD = "";
                String payslip;
                int Month = month;
                int Year = year;

                GetSalaryRates salaryRate = new GetSalaryRates();
                payslipNamePrint = payslipName;
                payslipEmpIDPrint = inputEmpId;
                payslipMonthYear = period;

                DateFormat sdfTime = new SimpleDateFormat("HH:mm");

                // SQL query to fetch attendance records for the specified employee and date range
                String query = "SELECT time_in, time_out FROM attendancerecordv4 WHERE employee_id = ? AND month = ? AND year = ?";

                int totalMinutes = 0;
                int totalHours = 0;

                try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
                     PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                    preparedStatement.setString(1, inputEmpId);
                    preparedStatement.setString(2, String.valueOf(Month));
                    preparedStatement.setString(3, String.valueOf(Year));

                    ResultSet resultSet = preparedStatement.executeQuery();

                    while (resultSet.next()) {
                        String timeInString = resultSet.getString("time_in");
                        String timeOutString = resultSet.getString("time_out");

                        Date timeIn = sdfTime.parse(timeInString);
                        Date timeOut = sdfTime.parse(timeOutString);
                        Date timeInDefault = sdfTime.parse("08:00");

                        long dailyHoursRendered;
                        if (timeIn.getTime() < 0) {
                            dailyHoursRendered = 0;
                        } else if (timeIn.getTime() > 900000) {
                            dailyHoursRendered = timeOut.getTime() - timeIn.getTime();
                            if (dailyHoursRendered > (5 * 1000 * 60 * 60)) {
                                dailyHoursRendered -= (1 * 1000 * 60 * 60);
                            }
                        } else {
                            dailyHoursRendered = timeOut.getTime() - timeInDefault.getTime();
                            if (dailyHoursRendered > (5 * 1000 * 60 * 60)) {
                                dailyHoursRendered -= (1 * 1000 * 60 * 60);
                            }
                        }

                        totalMinutes += (dailyHoursRendered / (1000 * 60)) % 60;
                        totalHours += (dailyHoursRendered / (1000 * 60 * 60));
                    }
                } catch (SQLException | ParseException e) {
                    e.printStackTrace();
                }

                // Adjust total hours and minutes
                totalHours += totalMinutes / 60;
                totalMinutes %= 60;


		String hourlyRate = salaryRate.getHourlyRate(inputEmpId);


		double hourlyRateDouble = Double.parseDouble(hourlyRate);
		double grossMonthlySalary = (totalHours + (totalMinutes/60))*hourlyRateDouble;
		double sssContribution = GovtDeductions.sss(grossMonthlySalary);
		double philHealthContribution = GovtDeductions.philHealth(grossMonthlySalary);
		double pagIbigContribution = GovtDeductions.pagIbig(grossMonthlySalary);
		double deductions1 = sssContribution + philHealthContribution + pagIbigContribution;
		double taxableIncome = grossMonthlySalary - (deductions1);

		DecimalFormat formatter = new DecimalFormat("#,###.00");
		String FILE_PATH = "./data/MotorPH Employee Data.csv";
		int HEADER_ROWS = 1;

		String emp_ID = inputEmpId;
                
                String allowanceQuery = "SELECT basic_salary, rice_subsidy, phone_allowance, clothing_allowance FROM motorph_employee_data WHERE employee_id = ?";
                
                try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
                     PreparedStatement preparedStatement = connection.prepareStatement(allowanceQuery)) {

                    preparedStatement.setString(1, inputEmpId);

                    ResultSet resultSet = preparedStatement.executeQuery();

                    while (resultSet.next()) {
                        double basicSalary = Double.parseDouble(resultSet.getString("basic_salary"));
                        String formattedBasicSalary = String.format("%,.2f", basicSalary);
                        payslipBasicSalary = ("\nBasic Salary(Base Computation only): "+ formattedBasicSalary);
                        riceSubsidy = Double.parseDouble(resultSet.getString("rice_subsidy"));
                        String formattedRiceSubsidy = String.format("%,.2f", riceSubsidy);
                        payslipRiceSubsidy = ("\nRice Subsidy: " + formattedRiceSubsidy);
                        phoneAllowance = Double.parseDouble(resultSet.getString("phone_allowance"));
                        String formattedPhoneAllowance = String.format("%,.2f", phoneAllowance);
                        payslipPhoneAllowance = ("\nPhone Allowance: " + formattedPhoneAllowance);
                        clothingAllowance = Double.parseDouble(resultSet.getString("clothing_allowance"));
                        String formattedClothingAllowance = String.format("%,.2f", clothingAllowance);
                        payslipClothingAllowance = ("\nClothing Allowance: " + formattedClothingAllowance);

                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
/*
		int intEmpID = Integer.parseInt(emp_ID);
		try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
			for (int i = 0; i < HEADER_ROWS; i++) {
				reader.readLine();
			}
			String line_allowance;
			while ((line_allowance = reader.readLine()) != null) {
				String[] employeeData = line_allowance.split(",");
				if (Integer.parseInt(employeeData[0]) == intEmpID) {
					double basicSalary = Double.parseDouble(employeeData[13]);
					String formattedBasicSalary = String.format("%,.2f", basicSalary);
                                        payslipBasicSalary = ("\nBasic Salary(Base Computation only): "+ formattedBasicSalary);
					riceSubsidy = Double.parseDouble(employeeData[14]);
					String formattedRiceSubsidy = String.format("%,.2f", riceSubsidy);
                                        payslipRiceSubsidy = ("\nRice Subsidy: " + formattedRiceSubsidy);
					phoneAllowance = Double.parseDouble(employeeData[15]);
					String formattedPhoneAllowance = String.format("%,.2f", phoneAllowance);
                                        payslipPhoneAllowance = ("\nPhone Allowance: " + formattedPhoneAllowance);
					clothingAllowance = Double.parseDouble(employeeData[16]);
					String formattedClothingAllowance = String.format("%,.2f", clothingAllowance);
                                        payslipClothingAllowance = ("\nClothing Allowance: " + formattedClothingAllowance);
				}
			}
		}
                */
//Ssian's allowances code ends here
                payslipGrossSalary = ("\n\nTotal Monthly Hours:            "+totalHours+"Hrs. "+totalMinutes+"mins. " + 
                        "\nHourly Rate:                    "+formatter.format(hourlyRateDouble) + 
                        "\n                               -------------" + 
                        "\nTotal Gross Monthly salary:     "+formatter.format(grossMonthlySalary));
                payslipDeductions = ("\n\n Less:" + 
                        "\nSSS:                "+formatter.format(sssContribution) +
                        "\nPhilHealth:         "+formatter.format(philHealthContribution) + 
                        "\nPagIbig:            "+formatter.format(pagIbigContribution)+ "     ("+formatter.format(deductions1)+")" + 
                        "\n                              -----------" + 
                        "\nTaxable Income:                "+formatter.format(taxableIncome));
//			Monthly Rate	              Tax Rate
//			20,832 and below	          No withholding tax
//			20,833 to below 33,333	      20% in excess of 20,833
//			33,333 to below 66,667	      2,500 plus 25% in excess of 33,333
//			66,667 to below 166,667	      10,833 plus 30% in excess of 66,667
//			166,667 to below 666,667	  40,833.33 plus 32% in excess over 166,667
//			666,667 and above	          200,833.33 plus 35% in excess of 666,667


//			withholding tax computation
		double withholdingTax;

		if (taxableIncome >= 666667) {
			withholdingTax = 200833.33 + ((taxableIncome - 666667) * .35);
		} else if (taxableIncome >= 166667) {
			withholdingTax = 40833.33 + ((taxableIncome - 166667) * .32);
		} else if (taxableIncome >= 66667) {
			withholdingTax = 10833 + ((taxableIncome - 66667) * .30);
		} else if (taxableIncome >= 33333) {
			withholdingTax = 2500 + ((taxableIncome - 33333) * .25);
		} else if (taxableIncome >= 20833) {
			withholdingTax = (taxableIncome - 20833) * .20;
		} else {
			withholdingTax = 0;
		}

		double netSalary = taxableIncome - withholdingTax + riceSubsidy + clothingAllowance + phoneAllowance;
                payslipNetSalary = ("\n\nLess:" + 
                        "\nWithholding Tax:               ("+formatter.format(withholdingTax)+")" + 
                        "\n                              -----------" + 
                        "\nNet Salary:                    "+formatter.format(netSalary) + 
                        "\n                              ===========" + 
                        "\n\n=========***Nothing follows***=============");
                
                payslip = ("Employee ID: " + payslipEmpIDPrint + 
                        "\nName: " + payslipNamePrint + 
                        "\nPay Period: " + payslipMonthYear + 
                        "\n" + payslipBasicSalary + "\n" + payslipRiceSubsidy + payslipPhoneAllowance + payslipClothingAllowance
                        + payslipGrossSalary + payslipDeductions + payslipNetSalary);
		// check original raw data from camu. check dates in attendance record sheet


        //run viewPayrollPop to update payslip section

        return payslip;
	}
    
}
