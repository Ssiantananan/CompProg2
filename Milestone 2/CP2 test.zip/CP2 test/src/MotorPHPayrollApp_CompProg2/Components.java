/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MotorPHPayrollApp_CompProg2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author ssianrosalejos
 */
public class Components {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/MotorPH";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "";
    private static final String API_KEY = "a00a0a27e6e7a242663b0872c7366fcb"; 
    private static final String GEOLOCATION_API_URL = "https://ipinfo.io/json";
    private static int userEmpID;
    private static String userFirstName;
    private static String userLocation;
    
    public static void getUserEmpID(int userEmpIDInput){
        userEmpID = userEmpIDInput;
        
        String query = "SELECT first_name FROM motorph_employee_data WHERE employee_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Set the parameter for the query
            preparedStatement.setInt(1, userEmpIDInput);

            // Execute the query
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                // Check if a matching record is found
                if (resultSet.next()) {
                    userFirstName = resultSet.getString("first_name");
                }
            }

        } catch (SQLException e) {
            // Handle SQLException as needed
            
        }
    }
    
    private static void getUserCity() throws Exception {
        URL url = new URL(GEOLOCATION_API_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.connect();

        int responseCode = conn.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) {
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            // Convert response to String
            String responseString = response.toString();

            // Parse the response to extract the city
            userLocation = parseCityFromJson(responseString);
        } else {
            throw new RuntimeException("Failed to get location data: HTTP response code " + responseCode);
        }
    }
    
    public static String  getWeatherInfo() throws Exception {
        getUserCity();
        String apiUrl = "http://api.openweathermap.org/data/2.5/weather?q=" + userLocation + "&units=metric&appid=" + API_KEY;
        String weatherInfo;
        try {
            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();

            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                // Parse JSON response
                String jsonResponse = response.toString();
                String weatherDescription = parseWeatherDescription(jsonResponse);
                double temperature = parseTemperature(jsonResponse);
                String cityName = parseCityName(jsonResponse);

                // Construct weather info string
                weatherInfo =  String.format("%.1f°C %s %s", temperature, cityName, weatherDescription);
                
                return weatherInfo;
            } else {
                
            }
        } catch (IOException e) {
        }
        return null;
    }
    
    private static String parseWeatherDescription(String jsonResponse) {
        int startIndex = jsonResponse.indexOf("\"description\":\"") + "\"description\":\"".length();
        int endIndex = jsonResponse.indexOf("\",", startIndex);
        return jsonResponse.substring(startIndex, endIndex);
    }

    private static double parseTemperature(String jsonResponse) {
        int startIndex = jsonResponse.indexOf("\"temp\":") + "\"temp\":".length();
        int endIndex = jsonResponse.indexOf(",", startIndex);
        String tempStr = jsonResponse.substring(startIndex, endIndex);
        return Double.parseDouble(tempStr);
    }

    private static String parseCityName(String jsonResponse) {
        int startIndex = jsonResponse.indexOf("\"name\":\"") + "\"name\":\"".length();
        int endIndex = jsonResponse.indexOf("\",", startIndex);
        return jsonResponse.substring(startIndex, endIndex);
    }
    
    private static String parseCityFromJson(String jsonString) {
        // Remove extraneous spaces
        jsonString = jsonString.replaceAll("\\s+", "");

        // Find the city in the JSON string
        String searchKey = "\"city\":\"";
        int searchKeyIndex = jsonString.indexOf(searchKey);
        if (searchKeyIndex == -1) { // Not found
            return "City not found";
        }
        int startIndex = searchKeyIndex + searchKey.length();
        int endIndex = jsonString.indexOf("\"", startIndex);

        if (endIndex == -1) {
            return "City not found";
        }
        return jsonString.substring(startIndex, endIndex);
    }
    
    public static String fetchUserFirstName(){
        return userFirstName;
    }
    
    public static int fetchUserEmpID(){
        return userEmpID;
    }
    
    
}
