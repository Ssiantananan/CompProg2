package MotorPHPayrollApp_CompProg2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GetSalaryRates {

	// Method to get the hourly wage of an employee
	public String getHourlyRate(String inputEmpId) {
            String DB_URL = "jdbc:mysql://localhost:3306/MotorPH"; // Replace with your database URL
            String DB_USERNAME = "root"; // Replace with your database username
            String DB_PASSWORD = ""; // Replace with your database password

            String hourlyRate = null;

            String query = "SELECT hourly_rate FROM motorph_employee_data WHERE employee_id = ?";

            try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
                 PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                // Set the employee ID parameter
                preparedStatement.setString(1, inputEmpId);

                // Execute the query
                ResultSet resultSet = preparedStatement.executeQuery();

                // Check if a result was returned and extract the hourly rate
                if (resultSet.next()) {
                    hourlyRate = resultSet.getString("hourly_rate");
                }

            } catch (SQLException e) {
            }

            return hourlyRate;
        }

	// Method to get the monthly wage of an employee
	public void getMonthlyRate() {

	}

}